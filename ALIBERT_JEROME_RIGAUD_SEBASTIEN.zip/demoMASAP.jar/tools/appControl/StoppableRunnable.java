package tools.appControl;

public interface StoppableRunnable extends Runnable {

	public void shutdown();

}
