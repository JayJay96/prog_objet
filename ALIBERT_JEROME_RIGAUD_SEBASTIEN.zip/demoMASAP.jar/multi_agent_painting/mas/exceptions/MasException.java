package multi_agent_painting.mas.exceptions;

public class MasException extends Exception {

	private static final long	serialVersionUID	= -6091983669693183650L;

	public MasException(final String string) {
		super(string);
	}

}
