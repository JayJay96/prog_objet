package multi_agent_painting.mas.exceptions;

public class MasInitException extends Exception {

	private static final long	serialVersionUID	= 2233848081164761018L;

	public MasInitException(final String string) {
		super(string);
	}

}
