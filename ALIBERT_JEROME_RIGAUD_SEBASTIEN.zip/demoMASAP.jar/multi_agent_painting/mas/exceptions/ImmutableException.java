package multi_agent_painting.mas.exceptions;

public class ImmutableException extends Exception {

	private static final long	serialVersionUID	= -1918895995719035251L;

	public ImmutableException(final String string) {
		super(string);
	}

}
