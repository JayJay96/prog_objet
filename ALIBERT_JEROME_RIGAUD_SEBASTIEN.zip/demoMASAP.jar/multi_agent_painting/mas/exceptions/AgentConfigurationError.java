package multi_agent_painting.mas.exceptions;

public class AgentConfigurationError extends Exception {

	/**
	 * 
	 */
	private static final long	serialVersionUID	= -4401835819398781935L;

	public AgentConfigurationError(final String string) {
		super(string);
	}

}
