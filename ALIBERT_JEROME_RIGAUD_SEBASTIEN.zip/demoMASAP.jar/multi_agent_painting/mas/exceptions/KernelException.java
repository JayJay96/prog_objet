package multi_agent_painting.mas.exceptions;

public class KernelException extends Exception {

	private static final long	serialVersionUID	= -1676600248825902734L;

	public KernelException(final String msg) {
		super(msg);
	}
}
