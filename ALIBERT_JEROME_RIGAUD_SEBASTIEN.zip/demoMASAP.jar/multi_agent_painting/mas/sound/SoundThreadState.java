package multi_agent_painting.mas.sound;

public enum SoundThreadState {
	PLAY, PAUSE, STEPBYSTEP
}
