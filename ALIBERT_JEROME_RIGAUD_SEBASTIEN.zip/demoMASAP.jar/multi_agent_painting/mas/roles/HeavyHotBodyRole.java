package multi_agent_painting.mas.roles;

/**
 * Created by Epulapp on 12/01/2017.
 */
public class HeavyHotBodyRole extends AbstractRole {
    public HeavyHotBodyRole(String name) {
        super(name);
    }

    public HeavyHotBodyRole() {
    }
}
