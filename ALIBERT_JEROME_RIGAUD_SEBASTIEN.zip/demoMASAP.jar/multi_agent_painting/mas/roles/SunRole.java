package multi_agent_painting.mas.roles;

/**
 * Created by Epulapp on 12/01/2017.
 */
public class SunRole extends AbstractRole {
    public SunRole(String name) {
        super(name);
    }

    public SunRole() {
    }
}
