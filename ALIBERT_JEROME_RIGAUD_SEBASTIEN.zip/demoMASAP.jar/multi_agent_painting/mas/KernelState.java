/**
 * 
 */
package multi_agent_painting.mas;

public enum KernelState {
	PLAY, PAUSE, STEPBYSTEP
}