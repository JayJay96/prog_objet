package multi_agent_painting.physics.laws;

public enum PhysicProperty {
	MASS, TEMPERATURE, PARITY
}
